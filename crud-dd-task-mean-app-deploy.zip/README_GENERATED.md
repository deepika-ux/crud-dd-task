Generated deployment artifacts:
- Dockerfiles (backend/frontend)
- docker-compose.yml
- GitHub Actions workflow
- nginx configs
